# Intelligent Code Review Risk Predictor Using Machine Learning

A complete Artificial Intelligence Lab project that predicts the review-risk level of a GitHub Pull Request as **Low, Medium, or High**.

## Project alignment
This implementation follows the submitted project outline:
- GitHub REST API data collection
- Data preprocessing
- Feature engineering and selection
- Low/Medium/High risk labeling
- Random Forest, XGBoost, and LightGBM comparison
- Accuracy, precision, recall, F1-score, and confusion matrix
- Final prediction interface

> Important modeling note: a genuine **pre-review** predictor must not use information that is only known after review/merge (for example, time-to-merge or final merge outcome) as prediction features. This project therefore keeps such fields for dataset context but does not feed them into the predictor.

## 1. Setup

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Optional GitHub token

Create a GitHub Personal Access Token and set it as an environment variable:

Windows PowerShell:
```powershell
$env:GITHUB_TOKEN="YOUR_TOKEN"
```

macOS/Linux:
```bash
export GITHUB_TOKEN="YOUR_TOKEN"
```

The collector also works without a token, but authenticated requests have a much higher API rate limit.

## 3. Collect Pull Request data

```bash
python -m src.collect_data --repo scikit-learn/scikit-learn --pages 3 --per-page 100
```

For a stronger dataset, repeat for several repositories:

```bash
python -m src.collect_data --repo pandas-dev/pandas --pages 3 --per-page 100
python -m src.collect_data --repo matplotlib/matplotlib --pages 3 --per-page 100
python -m src.collect_data --repo pallets/flask --pages 3 --per-page 100
```

## 4. Build labels and train models

```bash
python -m src.train
```

This creates:
- `models/best_model.joblib`
- `models/preprocessor.joblib`
- `reports/model_comparison.csv`
- `reports/classification_report.txt`
- `reports/confusion_matrix.png`
- `reports/feature_importance.csv`

## 5. Run the prediction app

```bash
streamlit run app.py
```

Then enter:
- Files changed
- Lines added
- Lines deleted
- Number of commits
- Number of comments
- PR age in days

The app returns Low/Medium/High risk.

## Project structure

```text
intelligent_code_review_risk_predictor/
│
├── app.py
├── requirements.txt
├── README.md
├── data/
│   └── pull_requests.csv
├── models/
├── reports/
└── src/
    ├── __init__.py
    ├── collect_data.py
    ├── preprocess.py
    ├── label.py
    ├── train.py
    └── predict.py
```

## Risk-label heuristic

Because raw GitHub pull requests normally do not contain an explicit "review risk" label, this implementation uses a transparent size/scope heuristic.

A score is calculated from:
- files changed
- additions
- deletions
- commits

The score is converted into:
- **Low**
- **Medium**
- **High**

This is a proof-of-concept labeling strategy, not a ground-truth defect label. For research-grade work, the next improvement would be to replace the heuristic with outcome-based labels such as post-merge bug/revert information while keeping those outcomes out of the input features.

## Models

The training pipeline compares:
1. Random Forest
2. XGBoost
3. LightGBM

The best model is selected using macro F1-score on the held-out test set.

## Viva/demo flow

1. Explain the problem.
2. Show collected GitHub PR metadata.
3. Show preprocessing and engineered features.
4. Explain why risk labels are needed.
5. Train three models.
6. Compare metrics.
7. Show confusion matrix.
8. Open Streamlit app.
9. Enter a small PR and show Low/Medium/High prediction.
10. Explain the limitation of heuristic labels and future improvement.
