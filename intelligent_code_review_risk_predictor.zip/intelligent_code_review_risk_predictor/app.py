import streamlit as st

from src.predict import predict_risk


st.set_page_config(
    page_title="PR Risk Predictor",
    page_icon="🔍",
    layout="centered",
)

st.title("🔍 Intelligent Code Review Risk Predictor")
st.write(
    "Predict the review-risk level of a GitHub Pull Request "
    "before human review."
)

st.info(
    "Risk classes: Low, Medium, High. "
    "The model is a proof-of-concept trained from PR metadata."
)

col1, col2 = st.columns(2)

with col1:
    files_changed = st.number_input("Files changed", min_value=0, value=5)
    additions = st.number_input("Lines added", min_value=0, value=50)
    deletions = st.number_input("Lines deleted", min_value=0, value=20)
    commits = st.number_input("Number of commits", min_value=0, value=2)

with col2:
    comments = st.number_input("Comments", min_value=0, value=1)
    review_comments = st.number_input(
        "Review comments", min_value=0, value=1
    )
    pr_age_days = st.number_input(
        "PR age (days)", min_value=0.0, value=1.0
    )

if st.button("Predict Risk", type="primary"):
    try:
        result, probability = predict_risk(
            files_changed,
            additions,
            deletions,
            commits,
            comments,
            review_comments,
            pr_age_days,
        )

        st.subheader(f"Predicted Risk: {result}")

        if result == "Low":
            st.success("This PR is predicted as Low Risk.")
        elif result == "Medium":
            st.warning("This PR is predicted as Medium Risk.")
        else:
            st.error("This PR is predicted as High Risk.")

        if probability:
            st.write("Prediction probabilities")
            st.bar_chart(probability)

    except FileNotFoundError as e:
        st.error(str(e))
        st.code("python -m src.train")
