Run the GitHub collector to populate pull_requests.csv. The training script creates a small demo dataset automatically if a sufficiently large CSV is not present.
