import argparse
import os
import time
from pathlib import Path

import pandas as pd
import requests

BASE_URL = "https://api.github.com"


def github_get(url, params=None):
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    token = os.getenv("GITHUB_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    response = requests.get(url, headers=headers, params=params, timeout=30)

    if response.status_code == 403:
        raise RuntimeError(
            "GitHub API rate limit reached. Set GITHUB_TOKEN and try again."
        )
    response.raise_for_status()
    return response.json()


def collect_repo(repo, pages=3, per_page=100):
    rows = []

    for page in range(1, pages + 1):
        url = f"{BASE_URL}/repos/{repo}/pulls"
        params = {
            "state": "all",
            "sort": "updated",
            "direction": "desc",
            "page": page,
            "per_page": per_page,
        }
        prs = github_get(url, params=params)

        if not prs:
            break

        for pr in prs:
            detail = github_get(pr["url"])

            created = pd.to_datetime(detail["created_at"], utc=True)
            updated = pd.to_datetime(detail["updated_at"], utc=True)
            age_days = max((updated - created).total_seconds() / 86400, 0)

            rows.append(
                {
                    "repository": repo,
                    "pr_number": detail["number"],
                    "title": detail.get("title", ""),
                    "files_changed": detail.get("changed_files", 0),
                    "additions": detail.get("additions", 0),
                    "deletions": detail.get("deletions", 0),
                    "commits": detail.get("commits", 0),
                    "comments": detail.get("comments", 0),
                    "review_comments": detail.get("review_comments", 0),
                    "pr_age_days": round(age_days, 3),
                    "merge_status": "merged" if detail.get("merged_at") else "not_merged",
                    "created_at": detail.get("created_at"),
                    "updated_at": detail.get("updated_at"),
                }
            )

        print(f"Collected page {page}: {len(prs)} PRs")
        time.sleep(0.2)

    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True, help="owner/repository")
    parser.add_argument("--pages", type=int, default=3)
    parser.add_argument("--per-page", type=int, default=100)
    parser.add_argument("--output", default="data/pull_requests.csv")
    args = parser.parse_args()

    df = collect_repo(args.repo, args.pages, args.per_page)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)

    if output.exists():
        old = pd.read_csv(output)
        df = pd.concat([old, df], ignore_index=True)

    df = df.drop_duplicates(subset=["repository", "pr_number"])
    df.to_csv(output, index=False)

    print(f"Saved {len(df)} unique pull requests to {output}")


if __name__ == "__main__":
    main()
