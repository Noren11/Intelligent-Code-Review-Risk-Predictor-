import numpy as np
import pandas as pd


def add_engineered_features(df):
    df = df.copy()

    numeric_cols = [
        "files_changed",
        "additions",
        "deletions",
        "commits",
        "comments",
        "review_comments",
        "pr_age_days",
    ]

    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    df["total_lines_changed"] = df["additions"] + df["deletions"]
    df["total_activity"] = (
        df["commits"] + df["comments"] + df["review_comments"]
    )
    df["change_density"] = df["total_lines_changed"] / df["files_changed"].replace(
        0, 1
    )

    return df


def assign_risk_labels(df):
    """Transparent proof-of-concept heuristic for Low/Medium/High risk."""
    df = add_engineered_features(df)

    # Log scaling prevents very large PRs from dominating the score.
    score = (
        0.30 * np.log1p(df["files_changed"])
        + 0.30 * np.log1p(df["total_lines_changed"])
        + 0.20 * np.log1p(df["commits"])
        + 0.10 * np.log1p(df["comments"])
        + 0.10 * np.log1p(df["review_comments"])
    )

    df["risk_score"] = score

    q1 = df["risk_score"].quantile(0.33)
    q2 = df["risk_score"].quantile(0.66)

    # If the dataset is very small or has little variation, fall back to
    # fixed thresholds so that all labels do not collapse into one class.
    if pd.isna(q1) or pd.isna(q2) or q1 == q2:
        q1, q2 = 1.0, 2.0

    df["risk_label"] = pd.cut(
        df["risk_score"],
        bins=[-np.inf, q1, q2, np.inf],
        labels=["Low", "Medium", "High"],
    ).astype(str)

    return df
