from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

from src.label import assign_risk_labels
from src.preprocess import prepare_features


DATA_PATH = Path("data/pull_requests.csv")
MODEL_DIR = Path("models")
REPORT_DIR = Path("reports")


def load_or_create_demo_data():
    if DATA_PATH.exists():
        df = pd.read_csv(DATA_PATH)
        if len(df) >= 30:
            return df

    # Small fallback dataset so the project can be demonstrated before
    # GitHub API collection is performed.
    demo = pd.DataFrame(
        {
            "repository": ["demo/repo"] * 45,
            "pr_number": list(range(1, 46)),
            "files_changed": [1,2,3,4,5,7,2,9,12,15,3,6,8,10,2,4,20,25,18,30,5,7,11,14,2,3,4,6,8,10,12,16,22,28,35,1,2,3,5,9,13,17,21,27,32],
            "additions": [5,10,15,20,30,45,12,80,120,150,25,50,70,100,8,35,250,400,300,600,40,55,90,130,7,14,22,45,65,110,180,220,350,500,800,3,11,18,27,75,140,260,420,700,900],
            "deletions": [1,2,3,5,4,10,3,20,25,40,5,15,10,30,2,8,60,90,70,120,8,10,25,30,2,3,6,10,15,25,30,50,70,90,150,1,2,4,5,12,30,45,80,120,200],
            "commits": [1,1,1,2,2,2,1,3,4,5,2,3,3,4,1,2,7,9,6,12,2,3,4,5,1,1,2,3,4,5,6,7,8,10,14,1,1,2,2,3,5,7,8,11,15],
            "comments": [0,0,1,0,2,1,0,3,4,5,1,2,3,2,0,1,8,10,7,12,2,3,4,5,0,0,1,2,3,4,5,6,8,10,15,0,0,1,1,2,4,6,8,10,14],
            "review_comments": [0,1,0,1,1,2,0,2,3,4,1,1,2,3,0,1,5,8,6,10,1,2,3,4,0,0,1,1,2,3,4,5,7,9,12,0,0,1,1,2,3,5,7,9,12],
            "pr_age_days": [0.1,0.2,0.3,0.5,0.4,0.8,0.2,1.2,2.0,2.5,0.4,0.8,1.0,1.5,0.1,0.5,4,5,3,7,0.7,1,1.4,2,0.1,0.2,0.3,0.6,0.8,1.2,2,2.5,3,4,6,0.1,0.2,0.4,0.5,1,2,3,4,5,8],
        }
    )
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    demo.to_csv(DATA_PATH, index=False)
    return demo


def train():
    MODEL_DIR.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)

    df = load_or_create_demo_data()
    df = assign_risk_labels(df)

    X, y, preprocessor = prepare_features(df)

    x_train, x_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42,
        stratify=y,
    )

    label_map = {"Low": 0, "Medium": 1, "High": 2}
    y_train_num = y_train.map(label_map)
    y_test_num = y_test.map(label_map)

    models = {
        "Random Forest": RandomForestClassifier(
            n_estimators=300,
            max_depth=10,
            random_state=42,
            class_weight="balanced",
        ),
        "XGBoost": XGBClassifier(
            n_estimators=250,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            objective="multi:softmax",
            num_class=3,
            eval_metric="mlogloss",
            random_state=42,
        ),
        "LightGBM": LGBMClassifier(
            n_estimators=250,
            learning_rate=0.05,
            num_leaves=31,
            random_state=42,
            verbosity=-1,
        ),
    }

    results = []
    trained = {}

    for name, model in models.items():
        pipe = Pipeline(
            [
                ("preprocessor", preprocessor),
                ("model", model),
            ]
        )

        pipe.fit(x_train, y_train_num)
        pred = pipe.predict(x_test)

        precision, recall, f1, _ = precision_recall_fscore_support(
            y_test_num, pred, average="macro", zero_division=0
        )

        results.append(
            {
                "Model": name,
                "Accuracy": accuracy_score(y_test_num, pred),
                "Precision_Macro": precision,
                "Recall_Macro": recall,
                "F1_Macro": f1,
            }
        )
        trained[name] = pipe

    comparison = pd.DataFrame(results).sort_values(
        "F1_Macro", ascending=False
    )
    comparison.to_csv(REPORT_DIR / "model_comparison.csv", index=False)

    best_name = comparison.iloc[0]["Model"]
    best_model = trained[best_name]
    joblib.dump(best_model, MODEL_DIR / "best_model.joblib")
    joblib.dump(label_map, MODEL_DIR / "label_map.joblib")

    best_pred = best_model.predict(x_test)
    report = classification_report(
        y_test_num,
        best_pred,
        target_names=["Low", "Medium", "High"],
        zero_division=0,
    )
    (REPORT_DIR / "classification_report.txt").write_text(
        f"Best model: {best_name}\n\n{report}",
        encoding="utf-8",
    )

    cm = confusion_matrix(y_test_num, best_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        xticklabels=["Low", "Medium", "High"],
        yticklabels=["Low", "Medium", "High"],
    )
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title(f"Confusion Matrix - {best_name}")
    plt.tight_layout()
    plt.savefig(REPORT_DIR / "confusion_matrix.png", dpi=200)
    plt.close()

    # Feature importance when the selected model exposes it.
    estimator = best_model.named_steps["model"]
    if hasattr(estimator, "feature_importances_"):
        importance = pd.DataFrame(
            {
                "Feature": X.columns,
                "Importance": estimator.feature_importances_,
            }
        ).sort_values("Importance", ascending=False)
        importance.to_csv(
            REPORT_DIR / "feature_importance.csv", index=False
        )

    print("\nModel comparison:")
    print(comparison.to_string(index=False))
    print(f"\nBest model: {best_name}")
    print(f"Saved to: {MODEL_DIR / 'best_model.joblib'}")


if __name__ == "__main__":
    train()
