import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


FEATURES = [
    "files_changed",
    "additions",
    "deletions",
    "commits",
    "comments",
    "review_comments",
    "pr_age_days",
    "total_lines_changed",
    "total_activity",
    "change_density",
]


def prepare_features(df):
    x = df[FEATURES].copy()
    y = df["risk_label"].copy()

    numeric_pipeline = Pipeline(
        [
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    preprocessor = ColumnTransformer(
        [("numeric", numeric_pipeline, FEATURES)],
        remainder="drop",
    )

    return x, y, preprocessor
