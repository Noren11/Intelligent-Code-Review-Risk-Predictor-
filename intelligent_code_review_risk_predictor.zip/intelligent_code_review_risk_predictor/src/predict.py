from pathlib import Path

import joblib
import pandas as pd

from src.label import add_engineered_features


MODEL_PATH = Path("models/best_model.joblib")


def predict_risk(
    files_changed,
    additions,
    deletions,
    commits,
    comments,
    review_comments,
    pr_age_days,
):
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "Model not found. Run: python -m src.train"
        )

    row = pd.DataFrame(
        [
            {
                "files_changed": files_changed,
                "additions": additions,
                "deletions": deletions,
                "commits": commits,
                "comments": comments,
                "review_comments": review_comments,
                "pr_age_days": pr_age_days,
            }
        ]
    )

    row = add_engineered_features(row)
    model = joblib.load(MODEL_PATH)

    numeric_prediction = int(model.predict(row)[0])
    labels = {0: "Low", 1: "Medium", 2: "High"}

    result = labels[numeric_prediction]
    probability = None

    if hasattr(model, "predict_proba"):
        probabilities = model.predict_proba(row)[0]
        probability = {
            labels[i]: float(probabilities[i])
            for i in range(len(probabilities))
        }

    return result, probability
